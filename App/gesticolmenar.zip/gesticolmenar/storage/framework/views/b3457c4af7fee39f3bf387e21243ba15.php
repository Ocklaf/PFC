<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center">Colmenares</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('apiaries.create')); ?>" class="btn btn-primary">Crear Colmena</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <table class="table text-center">
                    <thead>
                        <tr>
                            <th>Nombre Ubicación</th>
                            <th>Número de colmenas</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $apiaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($apiary->place_name); ?></td>
                                <td><?php echo e($apiary->beehives_quantity); ?></td>
                                <td class="d-flex justify-content-evenly">
                                    <a  href="<?php echo e(route('beehives.beehivesApiary', $apiary->id)); ?>" class="btn btn-primary"><i
                                            class="bi bi-eye"></i></a>
                                    <a href="<?php echo e(route('apiaries.edit', $apiary->id)); ?>" class="btn btn-primary"><i
                                            class="bi bi-pencil"></i></a>
                                    <form action="<?php echo e(route('apiaries.destroy', $apiary->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"><i class="bi bi-trash3"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/apiaries.blade.php ENDPATH**/ ?>