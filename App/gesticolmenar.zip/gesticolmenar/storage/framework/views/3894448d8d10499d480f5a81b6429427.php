<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="margin-bottom: 110px">
        <?php if(session('success')): ?>
            <div class="row  d-flex justify-content-center mt-5">
                <div class="alert alert-success text-center mb-3 col-6">
                    <?php echo e(session('success')); ?>

                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <h1 class="mt-4 text-center">Colmenas</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('beehives.addBeehiveToApiary', $apiary)); ?>" class="btn btn-primary">Añadir Colmena</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12">

                <?php if($beehives->count() > 0): ?>

                <table class="table text-center" style="width: 100%; overflow: hidden">
                    <thead>
                        <tr>
                            <th>Código</th>
                            <th>Tipo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $beehives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beehive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($beehive->diseases()->get()->count() && ($beehive->queen_change || $beehive->queen_no_inseminated || $beehive->queen_zanganera)): ?>
                                <tr class="table-danger-both">
                                    <td><i class="bi bi-heart-pulse me-2"></i>  <i class="fa-regular fa-chess-queen me-2"></i> <?php echo e($beehive->user_code); ?></td>
                            <?php elseif($beehive->diseases()->get()->count()): ?>
                                <tr class="table-danger">
                                    <td><i class="bi bi-heart-pulse me-2"></i> <?php echo e($beehive->user_code); ?></td>
                            <?php elseif($beehive->queen_change || $beehive->queen_no_inseminated || $beehive->queen_zanganera): ?>
                                <tr class="table-warning">
                                    <td><i class="fa-regular fa-chess-queen me-2"></i><?php echo e($beehive->user_code); ?></td>
                            <?php else: ?>
                            <tr>
                                <td><?php echo e($beehive->user_code); ?> </td>
                            <?php endif; ?>
                                <td><?php echo e($beehive->type); ?></td>
                                <td class="d-flex justify-content-evenly">
                                    <a href="<?php echo e(route('beehives.show', $beehive->id)); ?>" class="btn btn-primary"><i
                                            class="bi bi-eye"></i></a>

                                    <form action="<?php echo e(route('beehives.destroy', $beehive->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"><i class="bi bi-trash3"></i></button>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php else: ?>
                <div class="alert alert-info text-center mt-5">
                    No hay colmenas registradas
                </div>
                <?php endif; ?>

                <div class="d-flex justify-content-center mt-5">
                    <?php echo e($beehives->links()); ?>

                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/beehives/index.blade.php ENDPATH**/ ?>