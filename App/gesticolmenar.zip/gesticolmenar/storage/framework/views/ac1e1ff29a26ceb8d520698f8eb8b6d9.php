<?php $__env->startSection('content'); ?>
    <section style="margin-bottom: 110px">

        <div class="container">
            <div class="row d-flex justify-content-center align-items-center vh-100">
                <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                    <div class="card" style="border-radius: 15px;">
                        <div class="card-body p-4">
                            <h3 class="text-uppercase text-center mb-1">Editar Perfil</h3>

                            <form action="<?php echo e(route('users.update', $user)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="form-outline mb-1">
                                    <label class="form-label" for="name">Nombre</label>
                                    <input type="text" id="name" name="name" class="form-control form-control-lg"
                                        value="<?php echo e(old('name', $user->name)); ?>" />
                                    <?php if($errors->has('name')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="form-outline mb-1">
                                    <label class="form-label" for="surname">Apellidos</label>
                                    <input type="text" id="surname" name="surname" class="form-control form-control-lg"
                                        value="<?php echo e(old('surname', $user->surname)); ?>" />
                                    <?php if($errors->has('surname')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('surname')); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="form-outline mb-1">
                                    <label class="form-label" for="dni">DNI</label>
                                    <input type="text" id="dni" name="dni" class="form-control form-control-lg"
                                        value="<?php echo e(old('dni', $user->dni)); ?>" />
                                    <?php if($errors->has('dni')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('dni')); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="form-outline mb-1">
                                    <label class="form-label" for="explotation_code">Código Explotación Ganadera</label>
                                    <input type="text" id="explotation_code" name="explotation_code"
                                        class="form-control form-control-lg"
                                        value="<?php echo e(old('explotation_code', $user->explotation_code)); ?>" />
                                    <?php if($errors->has('explotation_code')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('explotation_code')); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="form-outline mb-1">
                                    <label class="form-label" for="email">Email</label>
                                    <input type="email" id="email" name="email" class="form-control form-control-lg"
                                        value="<?php echo e(old('email', $user->email)); ?>" />
                                    <?php if($errors->has('email')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="form-outline mb-1">
                                    <label class="form-label" for="password">Contraseña</label>
                                    <input type="password" id="password" name="password"
                                        class="form-control form-control-lg" />
                                    <?php if($errors->has('password')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="form-outline mb-3">
                                    <label class="form-label" for="password_confirmation">Repite contraseña</label>
                                    <input type="password" id="password_confirmation" name="password_confirmation"
                                        class="form-control form-control-lg" />
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <p class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="d-flex justify-content-evenly">
                                    <button type="submit"
                                        class="btn btn-primary btn-block  gradient-custom text-white">Editar</button>
                                    <a href="<?php echo e(route('apiaries.index')); ?>"
                                        class="btn btn-danger btn-block  gradient-custom text-white">Cancelar</a>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/users/edit.blade.php ENDPATH**/ ?>