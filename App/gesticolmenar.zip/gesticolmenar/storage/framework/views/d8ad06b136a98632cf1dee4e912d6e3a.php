<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5" style="margin-bottom: 110px">
        <?php if(session('success')): ?>
            <div class="row  d-flex justify-content-center mt-5">
                <div class="alert alert-success text-center mb-3 col-6">
                    <?php echo e(session('success')); ?>

                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <h1 class="text-center">Ubicaciones</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('places.create')); ?>" class="btn btn-primary">Añadir Ubicación</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12">

                <?php if($places->count() > 0): ?>

                    <table class="table text-center">
                        <thead>
                            <tr>
                                <th>Nombre del Lugar</th>
                                <th>Referencia catastral</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if(!$place->apiary()->count()): ?>
                                    <tr class="table-success">
                                        <td><?php echo e($place->name); ?></td>
                                    <?php else: ?>
                                    <tr>
                                        <td><?php echo e($place->name); ?></td>
                                <?php endif; ?>
                                
                                <td><?php echo e($place->catastral_code); ?></td>
                                <td class="d-flex justify-content-evenly">
                                    <a href="<?php echo e(route('places.show', $place->id)); ?>" class="btn btn-primary"><i
                                            class="bi bi-eye"></i></a>
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                        data-bs-target="#deleteModal"><i class="bi bi-trash3"></i></button>
                                </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                <?php else: ?>
                    <div class="alert alert-info text-center mt-5">
                        No hay ubicaciones registradas
                    </div>
                <?php endif; ?>

            </div>
        </div>


        <!-- Modal -->
        <?php if($places->count() > 0): ?>
            <div class="modal fade" id="deleteModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                aria-labelledby="deleteModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="deleteModalLabel">¡Advertencia!</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            ¿Estás seguro de que quieres eliminar esta ubicación? Esta acción no se puede deshacer. El
                            colmenar asociado junto con todas las colmenas serán eliminadas.
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-success" data-bs-dismiss="modal">Cerrar</button>
                            <form action="<?php echo e(route('places.destroy', $place)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Eliminar</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/places/index.blade.php ENDPATH**/ ?>