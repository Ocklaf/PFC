<?php $__env->startSection('content'); ?>
    <?php
        $honeyId = null;
        $pollenId = null;
        $apitoxineId = null;
    ?>
    <div class="container-fluid py-5 h-100" style="margin-bottom: 80px">
        <?php if(session('success')): ?>
            <div class="row  d-flex justify-content-center mt-1">
                <div class="alert alert-success text-center mb-3 col-6">
                    <?php echo e(session('success')); ?>

                </div>
            </div>
        <?php endif; ?>

        <?php if($beehive->user_id === auth()->user()->id): ?>
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-lg-10 mb-4 mb-lg-0">
                    <div class="card p-5 mb-3 beehive-card" style="border-radius: .5rem;">
                        <div class="row g-0">
                            <div class="col-md-2 gradient-custom text-center"
                                style="border-top-left-radius: .5rem; border-bottom-left-radius: .5rem;">
                                <i class="bi bi-archive" style="font-size: 4rem; color: #461400"></i>
                                <h5 class="text-black mb-4 mt-2">Código: <?php echo e($beehive->user_code); ?></h5>
                                <a href="<?php echo e(route('beehives.edit', $beehive)); ?>" class="btn btn-primary"><i
                                        class="bi bi-pencil"></i></a>
                            </div>

                            
                            <div class="col-md-3">
                                <div class="card-body p-4 .beehive-card">
                                    <h6 class="text-center">Información</h6>
                                    <hr class="mt-0 mb-4">
                                    <div class="row pt-1">
                                        <div class="col-12">
                                            <h6>Tipo de colmena</h6>
                                            <p class="text-muted"><?php echo e($beehive->type); ?></p>
                                        </div>
                                        <div class="col-12">
                                            <h6>Reina</h6>
                                            <p class="text-muted d-flex justify-content-between pe-5"><?php echo e($queen->race); ?> 
                                                <a href="<?php echo e(route('queens.edit', $beehive->queen_id)); ?>" class="btn btn-primary"><i
                                                        class="bi bi-pencil"></i></a></p>
                                        </div>
                                        <div class="col-12">
                                            <h6>Cuadros de Miel</h6>
                                            <p class="text-muted"><?php echo e($beehive->honey_frames); ?></p>
                                        </div>
                                        <div class="col-12">
                                            <h6>Cuadros de Polen</h6>
                                            <p class="text-muted"><?php echo e($beehive->pollen_frames); ?></p>
                                        </div>
                                        <div class="col-12">
                                            <h6>Cuadros de Cría</h6>
                                            <p class="text-muted"><?php echo e($beehive->brood_frames); ?></p>
                                        </div>
                                        <div class="col-12">
                                            <h6>Colmenar al que pertenece</h6>
                                            <p class="text-muted"><?php echo e($beehive->place_name); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="col-md-3">
                                <div class="card-body p-4 .beehive-card">
                                    <h6 class="text-center">Productos</h6>
                                    <hr class="mt-0 mb-4">
                                    <div class="row pt-1">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12">
                                                <h6><?php echo e($product->type); ?></h6>
                                                <?php if($product->type === 'Miel'): ?>
                                                    <?php
                                                        $honeyId = $product->id;
                                                        $honeyQuantity = $product->grams;
                                                    ?>
                                                    <div class="text-muted d-flex justify-content-between mb-3">
                                                        <p class="product-quantity"> <?php echo e($product->grams / 1000); ?> kg </p>
                                                        <p> <button data-bs-toggle="modal"
                                                                data-bs-target="#modalEditProductHoney"
                                                                class="btn btn-primary"><i
                                                                    class="bi bi-pencil"></i></button></p>
                                                        <form action="<?php echo e(route('products.destroy', $product)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"><i
                                                                    class="bi bi-trash3"></i></button>
                                                        </form>
                                                    </div>
                                                <?php elseif($product->type === 'Polen'): ?>
                                                    <?php
                                                        $pollenId = $product->id;
                                                        $pollenQuantity = $product->grams;
                                                    ?>
                                                    <div class="text-muted d-flex justify-content-between mb-3">
                                                        <p class="product-quantity"> <?php echo e($product->grams / 1000); ?> kg </p>
                                                        <p> <button data-bs-toggle="modal"
                                                                data-bs-target="#modalEditProductPollen"
                                                                class="btn btn-primary"><i
                                                                    class="bi bi-pencil"></i></button></p>

                                                        <form action="<?php echo e(route('products.destroy', $product)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"><i
                                                                    class="bi bi-trash3"></i></button>
                                                        </form>
                                                    </div>
                                                <?php else: ?>
                                                    <?php
                                                        $apitoxineId = $product->id;
                                                        $apitoxineQuantity = $product->grams;
                                                    ?>
                                                    <div class="text-muted d-flex justify-content-between mb-3">

                                                        <p class="product-quantity"><?php echo e($product->grams); ?> grs </p>
                                                        <p><button data-bs-toggle="modal"
                                                                data-bs-target="#modalEditProductApitoxine"
                                                                class="btn btn-primary"><i
                                                                    class="bi bi-pencil"></i></button>


                                                        <form action="<?php echo e(route('products.destroy', $product)); ?>"
                                                            method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger"><i
                                                                    class="bi bi-trash3"></i></button>
                                                        </form>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-12">
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modalAddProduct">
                                                Añadir Producto
                                            </button>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            
                            <div class="col-md-3">
                                <div class="card-body p-4 .beehive-card">
                                    <h6 class="text-center">Enfermedades</h6>
                                    <hr class="mt-0 mb-4">
                                    <div class="row pt-1">
                                        <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <h6><?php echo e($disease->name); ?></h6>
                                            <div class="col-12 d-flex justify-content-between mb-3">
                                                <p class="text-muted">Tratar:
                                                    <?php echo e(date('d-m-Y', strtotime($disease->treatment_repeat_date))); ?></p>
                                                <p><a href="<?php echo e(route('diseases.edit', $disease)); ?>"
                                                        class="btn btn-primary"><i class="bi bi-pencil"></i></a>
                                                <form action="<?php echo e(route('diseases.destroy', $disease)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger"><i
                                                            class="bi bi-trash3"></i></button>
                                                </form>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12">
                                            <a type="button" class="btn btn-primary"
                                                href="<?php echo e(route('diseases.addDiseaseToBeehive', $beehive)); ?>">Registrar
                                                Enfermedad</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="row  d-flex justify-content-center mt-5">
                <div class="alert alert-danger text-center mb-3 col-6">
                    Error: No tienes permisos para ver esta colmena
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Modal Add Product -->
    <div class="modal fade" id="modalAddProduct" tabindex="-1" aria-labelledby="modalAddProductLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="modalAddProductLabel">Añadir Producto</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <?php
                        $options = ['Miel', 'Polen', 'Apitoxina'];
                        $types = [];
                        foreach ($products as $product) {
                            array_push($types, $product->type);
                        }
                        $types = array_diff($options, $types);
                    ?>

                    <?php if(count($types) > 0): ?>

                        <form action="<?php echo e(route('products.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-outline mb-1">
                                <label class="form-label" for="type">Producto</label>
                                <select class="form-select form-select-lg" name="type" id="type">
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-outline mb-4">
                                <label class="form-label" for="grams">Cantidad en gramos</label>
                                <input type="number" id="grams" name="grams" class="form-control form-control-lg"
                                    value="<?php echo e(old('grams')); ?>" />
                                <?php if($errors->has('grams')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('grams')); ?></p>
                                <?php endif; ?>
                            </div>
                            <input type="text" name="beehive_id" value="<?php echo e($beehive->id); ?>" hidden>
                            <button type="submit" class="btn btn-primary">Añadir</button>
                        </form>

                    <?php else: ?>
                        <p class="alert alert-danger text-center">
                            Esta colmena ya tiene todos los productos.
                        </p>
                    <?php endif; ?>

                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                </div>

            </div>
        </div>
    </div>


    <!-- Modal Edit Product Honey-->
    <?php if($honeyId != null): ?>
        <div class="modal fade" id="modalEditProductHoney" tabindex="-1" aria-labelledby="modalEditProductLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="modalEditProductLabel">Editar cantidad Miel</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form action="<?php echo e(route('products.update', $honeyId)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-outline mb-4">
                                <label class="form-label" for="grams">Cantidad en gramos</label>
                                <input type="number" min="0" id="grams" name="grams"
                                    class="form-control form-control-lg" value="<?php echo e(old('grams', $honeyQuantity)); ?>" />
                                <?php if($errors->has('grams')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('grams')); ?></p>
                                <?php endif; ?>
                            </div>
                            <input type="text" name="beehive_id" value="<?php echo e($beehive->id); ?>" hidden>
                            <input type="text" name="type" value="Miel" hidden>
                            <button type="submit" class="btn btn-primary">Editar</button>
                        </form>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Modal Edit Product Pollen-->
    <?php if($pollenId != null): ?>
        <div class="modal fade" id="modalEditProductPollen" tabindex="-1" aria-labelledby="modalEditProductLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="modalEditProductLabel">Editar cantidad Polen</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form action="<?php echo e(route('products.update', $pollenId)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-outline mb-4">
                                <label class="form-label" for="grams">Cantidad en gramos</label>
                                <input type="number" min="0" id="grams" name="grams"
                                    class="form-control form-control-lg" value="<?php echo e(old('grams', $pollenQuantity)); ?>" />
                                <?php if($errors->has('grams')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('grams')); ?></p>
                                <?php endif; ?>
                            </div>
                            <input type="text" name="beehive_id" value="<?php echo e($beehive->id); ?>" hidden>
                            <input type="text" name="type" value="Polen" hidden>
                            <button type="submit" class="btn btn-primary">Editar</button>
                        </form>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Modal Edit Product Apitoxine-->
    <?php if($apitoxineId != null): ?>
        <div class="modal fade" id="modalEditProductApitoxine" tabindex="-1" aria-labelledby="modalEditProductLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="modalEditProductLabel">Editar cantidad Apitoxina</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <form action="<?php echo e(route('products.update', $apitoxineId)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="form-outline mb-4">
                                <label class="form-label" for="grams">Cantidad en gramos</label>
                                <input type="number" min="0" id="grams" name="grams"
                                    class="form-control form-control-lg"
                                    value="<?php echo e(old('grams', $apitoxineQuantity)); ?>" />
                                <?php if($errors->has('grams')): ?>
                                    <p class="text-danger"><?php echo e($errors->first('grams')); ?></p>
                                <?php endif; ?>
                            </div>
                            <input type="text" name="beehive_id" value="<?php echo e($beehive->id); ?>" hidden>
                            <input type="text" name="type" value="Apitoxina" hidden>
                            <button type="submit" class="btn btn-primary">Editar</button>
                        </form>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                    
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/beehives/show.blade.php ENDPATH**/ ?>