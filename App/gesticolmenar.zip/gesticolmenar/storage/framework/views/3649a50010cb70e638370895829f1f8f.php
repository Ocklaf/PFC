<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5" style="margin-bottom: 110px">
        <?php if($apiariesTasks->count()): ?>
            <div class="row ">
                <h2 class="text-center mb-4">Tareas pendientes</h2>
                <?php $__currentLoopData = $apiariesTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apiaryTask): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col d-flex justify-content-center mb-4">
                        <div class="card" style="width: 19rem;">
                            <div class="card-body">
                                <h5 class="card-title d-flex justify-content-between"><?php echo e($apiaryTask->place_name); ?> <a
                                        href="<?php echo e(route('apiaries.edit', $apiaryTask->id)); ?>"
                                        class="btn btn-primary card-link"><i class="bi bi-pencil"></i></a></h5>
                                <h6 class="card-subtitle mb-2 text-muted">Próxima visita:
                                    <?php echo e(date('d-m-Y', strtotime($apiaryTask->next_visit))); ?></h6>
                                <hr>

                                <ul class="list-group mt-3 mb-3">
                                    <?php if($apiaryTask->collect_honey): ?>
                                        <li class="list-group-item">Recolectar Miel</li>
                                    <?php endif; ?>

                                    <?php if($apiaryTask->collect_pollen): ?>
                                        <li class="list-group-item">Recolectar Polen</li>
                                    <?php endif; ?>

                                    <?php if($apiaryTask->collect_apitoxine): ?>
                                        <li class="list-group-item">Recolectar Apitoxina</li>
                                    <?php endif; ?>

                                    <?php if($apiaryTask->refill_water): ?>
                                        <li class="list-group-item">Rellenar depósitos de agua</li>
                                    <?php endif; ?>

                                    <?php if($apiaryTask->clear_apiary): ?>
                                        <li class="list-group-item">Limpieza y desbrozado</li>
                                    <?php endif; ?>
                                </ul>
                                <h6>Anotaciones</h6>
                                <p class="card-text"><?php echo e($apiaryTask->others); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if($beehivesWithDiseases->count()): ?>
            <div class="row">
                <h2 class="text-center mb-4 mt-4">Colmenas en tratamiento</h2>
                <?php $__currentLoopData = $beehivesWithDiseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beehiveWithDisease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col d-flex justify-content-center mb-4">
                        <div class="card" style="width: 19rem;">
                            <div class="card-body">
                                <h5 class="card-title d-flex justify-content-between">Colmena: <?php echo e($beehiveWithDisease->user_code); ?> <a
                                  href="<?php echo e(route('beehives.show', $beehiveWithDisease->id)); ?>"
                                  class="btn btn-primary card-link"><i class="bi bi-pencil"></i></a></h5>
                                <h6 class="card-subtitle mb-2 text-muted">Colmenar: <?php echo e($beehiveWithDisease->place_name); ?> </h6>
                                <hr>
                                <?php $__currentLoopData = $beehiveWithDisease->diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h6 class="card-text mt-4 mb-3"><?php echo e($disease->name); ?></h6>
                                    <p class="card-text">Fecha tratamiento:
                                        <?php echo e(date('d-m-Y', strtotime($disease->treatment_start_date))); ?></p>
                                    <p class="card-text">Próximo tratamiento:
                                        <?php echo e(date('d-m-Y', strtotime($disease->treatment_repeat_date))); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endif; ?>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/apiaries/tasks.blade.php ENDPATH**/ ?>