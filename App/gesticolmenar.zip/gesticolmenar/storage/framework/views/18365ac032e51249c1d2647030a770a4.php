<?php $__env->startSection('content'); ?>
    <section class="container" style="margin-bottom: 110px">

        <?php if(!count($freePlaces) && $path === 'apiaries.store'): ?>
            <div class="row d-flex justify-content-center mt-4">
                <div class="col-lg-6 col-md-8">
                    
                    <div class="alert alert-danger text-center">
                        No existen Ubicaciones disponibles, debes añadir una antes de añadir un colmenar.
                    </div>
                    
                    
                </div>
            </div>
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 col-md-8">
                    <div class="text-center">
                        <a href="<?php echo e(route('places.create')); ?>" class="btn btn-primary">Añadir Ubicación</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="row d-flex justify-content-center mt-5">
            <div class="col-12 col-md-9 col-lg-7 col-xl-6 mb-5">
                <div class="card" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <?php if($path === 'apiaries.update'): ?>
                            <h3 class="text-uppercase text-center mb-1">Editar Colmenar</h3>
                        <?php else: ?>
                            <h3 class="text-uppercase text-center mb-1">Añadir Colmenar</h3>
                        <?php endif; ?>

                        <form action="<?php echo e(route($path, $apiary)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if($path === 'apiaries.update'): ?>
                                <?php echo method_field('PATCH'); ?>
                            <?php endif; ?>

                            <?php if(count($freePlaces)): ?>
                                <div class="form-outline">
                                    <label class="form-label" for="type">Emplazamiento</label>
                                    <select class="form-select form-select-lg" name="place_id" id="place_id">
                                        <?php $__currentLoopData = $freePlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>


                                <div class="form-outline mt-2 mb-1">
                                    <label class="form-label" for="last_visit">Fecha visita al colmenar</label>
                                    <?php if($apiary->last_visit === null): ?>
                                        <input class="form-control form-control-lg" type="date" name="last_visit"
                                            id="last_visit">
                                    <?php else: ?>
                                        <input class="form-control form-control-lg" type="date" name="last_visit"
                                            id="last_visit"
                                            value="<?php echo e(old('last_visit', date('Y-m-d', strtotime($apiary->last_visit)))); ?>">
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['last_visit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-outline mt-2 mb-1">
                                    <label class="form-label" for="next_visit">Próxima visita al colmenar</label>
                                    <?php if($apiary->next_visit === null): ?>
                                        <input class="form-control form-control-lg" type="date" name="next_visit"
                                            id="next_visit">
                                    <?php else: ?>
                                        <input class="form-control form-control-lg" type="date" name="next_visit"
                                            id="next_visit"
                                            value="<?php echo e(old('next_visit', date('Y-m-d', strtotime($apiary->next_visit)))); ?>">
                                    <?php endif; ?>
                                    <?php $__errorArgs = ['next_visit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <h4 class="h4 mt-4">Tareas próxima visita</h4>

                                <div class="form-outline mt-2 mb-1">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                            <?php echo e(old('collect_honey', $apiary->collect_honey === 1 ? 'checked' : '')); ?>

                                            id="collect_honey" name="collect_honey">
                                        <label class="form-check-label" for="collect_honey">
                                            Recolectar Miel
                                        </label>
                                    </div>
                                </div>

                                <div class="form-outline mt-2 mb-1">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                            <?php echo e(old('collect_pollen', $apiary->collect_pollen === 1 ? 'checked' : '')); ?>

                                            id="collect_pollen" name="collect_pollen">
                                        <label class="form-check-label" for="collect_pollen">
                                            Recolectar Polen
                                        </label>
                                    </div>
                                </div>

                                <div class="form-outline mt-2 mb-1">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                            <?php echo e(old('collect_apitoxine', $apiary->collect_apitoxine === 1 ? 'checked' : '')); ?>

                                            id="collect_apitoxine" name="collect_apitoxine">
                                        <label class="form-check-label" for="collect_apitoxine">
                                            Recolectar Apitoxina
                                        </label>
                                    </div>
                                </div>

                                <div class="form-outline mt-2 mb-1">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                            <?php echo e(old('refill_water', $apiary->refill_water === 1 ? 'checked' : '')); ?>

                                            id="refill_water" name="refill_water">
                                        <label class="form-check-label" for="refill_water">
                                            Rellenar depósitos de agua
                                        </label>
                                    </div>
                                </div>

                                <div class="form-outline mt-2 mb-1">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                            <?php echo e(old('clear_apiary', $apiary->clear_apiary === 1 ? 'checked' : '')); ?>

                                            id="clear_apiary" name="clear_apiary">
                                        <label class="form-check-label" for="clear_apiary">
                                            Tareas de limpieza y desbrozado
                                        </label>
                                    </div>
                                </div>

                                <div class="form-outline mt-3 mb-1">
                                    <div class="form-floating">
                                        <textarea name="others" class="form-control" placeholder="Leave a comment here" id="others" style="height: 150px"><?php echo e(old('others', $apiary->others)); ?></textarea>
                                        <label for="others">Otras y/o anotaciones</label>
                                        <?php if($errors->has('others')): ?>
                                            <p class="text-danger"><?php echo e($errors->first('others')); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(count($freePlaces)): ?>
                                <div class="d-flex justify-content-evenly mt-4">
                                    <?php if($path === 'apiaries.update'): ?>
                                        <button type="submit"
                                            class="btn btn-primary btn-block  gradient-custom text-white">Editar</button>
                                    <?php else: ?>
                                        <button type="submit"
                                            class="btn btn-primary btn-block  gradient-custom text-white">Añadir</button>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('apiaries.index')); ?>"
                                        class="btn btn-danger btn-block  gradient-custom text-white">Cancelar</a>
                                </div>
                            <?php endif; ?>

                        </form>

                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/apiaries/form.blade.php ENDPATH**/ ?>