<?php $__env->startSection('content'); ?>

    <div id="app">

        <div class="container-fluid">
            <h1 class="text-center p-3 mt-4 mb-4">Total de Kg de Polen por Año</h1>
            <div class="row">
                <div class="col-12">
                    <div class="card rounded">
                        <div class="card-body py-3 px-3">
                            <?php echo $pollenApiaryChart->container(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        </main>
    </div>

    
    <?php if($pollenApiaryChart): ?>
    <?php echo $pollenApiaryChart->script(); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/charts/totalPollen.blade.php ENDPATH**/ ?>