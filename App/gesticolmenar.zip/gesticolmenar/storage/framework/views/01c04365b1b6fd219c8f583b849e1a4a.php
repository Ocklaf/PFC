<?php $__env->startSection('content'); ?>
    <div class="container-fluid" style="margin-bottom: 110px">
        <div class="row">
            <div class="col-12">
                <h1 class="mt-4 text-center">Colmenas</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <a href="<?php echo e(route('beehives.create')); ?>" class="btn btn-primary">Crear Colmena</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <table class="table text-center" style="width: 100%; overflow: hidden">
                    <thead>
                        <tr>
                            <th>Tipo Colmena</th>
                            <th>Marcos de miel</th>
                            <th>Marcos de polen</th>
                            <th>Marcos de cría</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $beehives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beehive): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($beehive->type); ?></td>
                                <td><?php echo e($beehive->honey_frames); ?></td>
                                <td><?php echo e($beehive->pollen_frames); ?></td>
                                <td><?php echo e($beehive->brood_frames); ?></td>
                                <td class="d-flex justify-content-evenly">
                                    <a href="<?php echo e(route('beehives.show', $beehive->id)); ?>" class="btn btn-primary"><i
                                            class="bi bi-eye"></i></a>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="d-flex justify-content-center mt-5">
                    <?php echo e($beehives->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/beehives.blade.php ENDPATH**/ ?>