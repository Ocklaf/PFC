<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/favicon.ico')); ?>">
</head>

<body>

    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand ms-3" href="<?php echo e(route('apiaries.index')); ?>">
                <img src="<?php echo e(asset('img/logo.png')); ?>" width="50" alt="Imagen del logotipo" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" aria-current="page" href="<?php echo e(route('apiaries.index')); ?>">Colmenares</a>
                    <a class="nav-link" href="<?php echo e(route('places.index')); ?>">Ubicaciones</a>
                    <a class="nav-link me-5" href="<?php echo e(route('queens.index')); ?>">Reinas disponibles</a>
                    <a class="nav-link" href="<?php echo e(route('users.index')); ?>"> <i class="bi bi-person-circle me-2 h5"></i></a>
                    <a class="nav-link" href="<?php echo e(route('logout')); ?>">
                        <i class="bi bi-box-arrow-right h5"></i>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <footer class="container-fluid text-center icons-copyright fixed-bottom" style="height: 80px">
        <div class="p-1 pb-0">
            <section class="">
                <a class="btn text-white btn-floating m-1" style="background-color: #0082ca; font-size: 12px" target="_blank"
                    href="https://www.linkedin.com/in/josevicentefalco/" role="button"><i
                        class="bi bi-linkedin"></i></a>
                <a class="btn text-white btn-floating m-1" style="background-color: #333333; font-size: 12px" target="_blank"
                    href="https://github.com/Ocklaf" role="button"><i class="bi bi-github"></i></a>
            </section>
        </div>

        <div class="text-center p-2 copyright">
            © <?php echo e(date('Y')); ?> Copyright: José Vicente Falcó Milla
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
    <script src="https://kit.fontawesome.com/5b4a7e4489.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js" charset="utf-8"></script>
</body>

</html>
<?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/layouts/app.blade.php ENDPATH**/ ?>