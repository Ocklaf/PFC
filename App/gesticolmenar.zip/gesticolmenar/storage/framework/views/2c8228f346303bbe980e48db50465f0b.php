<?php $__env->startSection('content'); ?>
    <section class="container" style="margin-bottom: 110px">
        <div class="row d-flex justify-content-center mt-5">
            <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                <div class="card" style="border-radius: 15px;">
                    <div class="card-body p-4">

                        <?php if($path === 'diseases.update'): ?>
                            <h3 class="text-uppercase text-center mb-1">Editar Enfermedad</h3>
                        <?php else: ?>
                            <h3 class="text-uppercase text-center mb-1">Registrar Enfermedad</h3>
                        <?php endif; ?>

                        <form action="<?php echo e(route($path, $disease)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <?php if($path === 'diseases.update'): ?>
                                <?php echo method_field('PATCH'); ?>
                            <?php endif; ?>

                            <div class="form-outline mb-1">
                                <label class="form-label" for="name"></label>
                                <select class="form-select form-select-lg" name="name" id="name">
                                    <?php $__currentLoopData = $diseasesOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diseaseOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($diseaseOption); ?>" <?php echo e(old('name', $disease->name) == $diseaseOption ? 'selected' : ''); ?>><?php echo e($diseaseOption); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-outline mb-1">
                                <label class="form-label" for="treatment_start_date">Fecha inicio tratamiento</label>
                                <?php if($disease->treatment_start_date === null): ?>
                                <input class="form-control form-control-lg" type="date" name="treatment_start_date" id="treatment_start_date">
                                <?php else: ?>
                                <input class="form-control form-control-lg" type="date" name="treatment_start_date" id="treatment_start_date" value="<?php echo e(old('treatment_start_date', date('Y-m-d', strtotime($disease->treatment_start_date)))); ?>">
                                <?php endif; ?>
                                <?php $__errorArgs = ['treatment_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-outline mb-1">
                                <label class="form-label" for="treatment_repeat_date">Repetir tratamiento en</label>
                                <select class="form-select form-select-lg" name="treatment_repeat_date" id="treatment_repeat_date">
                                        <option value="7">7 días</option>
                                        <option value="15">15 días</option>
                                        <option value="30">30 días</option>
                                </select>
                            </div>

                            <input type="text" name="beehive_id" value="<?php echo e($beehive); ?>" hidden>

                            <div class="d-flex justify-content-evenly mt-4">

                                <?php if($path === 'diseases.update'): ?>
                                    <button type="submit"
                                        class="btn btn-primary btn-block  gradient-custom text-white">Editar</button>
                                <?php else: ?>
                                    <button type="submit"
                                        class="btn btn-primary btn-block  gradient-custom text-white">Añadir</button>
                                <?php endif; ?>

                                <a href="<?php echo e(route('beehives.show', $beehive)); ?>"
                                    class="btn btn-danger btn-block  gradient-custom text-white">Cancelar</a>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/diseases/form.blade.php ENDPATH**/ ?>