<?php $__env->startSection('content'); ?>

    <div id="app">

        <div class="container-fluid">
            <h1 class="text-center p-3 mt-4 mb-4">Kg de Miel por Colmenar</h1>
            <div class="row">
                <div class="col-12">
                    <div class="card rounded">
                        <div class="card-body py-3 px-3">
                            <?php echo $honeyApiaryChart->container(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        </main>
    </div>

    
    <?php if($honeyApiaryChart): ?>
    <?php echo $honeyApiaryChart->script(); ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nostromo/Documentos/DAW/PFC/App/gesticolmenar/resources/views/charts/honey.blade.php ENDPATH**/ ?>